package com.scor.testscopeapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestScopeApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestScopeApiApplication.class, args);
	}

}
